# Quickstart

curl -fsSL https://doe.cloud/get | sudo -H sh

### Using DOE
    $ doe
    Usage: doe <command>
